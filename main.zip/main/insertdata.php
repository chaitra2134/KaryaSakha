


<?php

/*
Author : Prizam Sarkhi
Date : 19/07/2023 @ 20:38

Main backend process which will store user information in the table, send email to the user
and make a copy of the template file
*/

if(isset($_POST['submit']))
{
    //Variables that will store data from the form
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $userName = $_POST['userName'];
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $profession = $_POST['profession'];
    $SESSION['verifyUserName'] = $userName;
    
    
//Variables that store the information requird to establish connection with the database
$servername = "localhost";
$userNameServer = "root";
$password = "";
$dbname = "KaryaSakha";

$conn = new mysqli($servername,$userNameServer,$password,$dbname);


    if($conn->connect_error)
    {
        die("Connection failed ". $conn->connect_error);
    }
    else
    {
        $sql = "INSERT INTO user(userName,firstName,lastName,pass,
        email,dob,gender,profession)
        Values('$userName','$firstName','$lastName','$pass','$email','$dob','$gender','$profession')";

        if($conn->query($sql)===TRUE)
        {
            echo "Values inserted successfully";
            
        }
        else
        {
            echo "Failed ", $conn->error;
        }
    }
  $conn->close();

        
        
}
?>