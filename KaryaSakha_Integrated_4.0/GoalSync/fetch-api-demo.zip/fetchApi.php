<?php
// If the data is sent through POST Method
if($_SERVER['REQUEST_METHOD']==='POST')
{
    $name_from_javascript = $_POST['inputName']; //The variable that we appended the the form object
    
    // Implement your code to store this variable in the tables




    //Optional 
    // this statement will be sent back to the js file as data
    echo "Variable received Successfully ", $name_from_javascript; 
}


?>