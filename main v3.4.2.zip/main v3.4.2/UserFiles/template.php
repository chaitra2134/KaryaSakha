
<!-- Author : Prizam Sarkhi
Date : 19/07/2023 @ 20:20

Demo template file whose contents 
will be copied into the newly created file -->

<?php
session_start();
if(!isset($_SESSION['un']))
{
    header("Location: ../Frontend/LogIn/LogIn.html");
    exit();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
</head>
<body>
    
    <h1>Welcome to KaryaSakha!!</h1>
    <a href="../Backend/Logout_php/LogOut.php">Log out</a>
    
</body>
</html>