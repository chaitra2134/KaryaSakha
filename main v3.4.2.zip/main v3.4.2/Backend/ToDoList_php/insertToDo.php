<?php

include '../../Backend/Connection_Database_Table/Connection.php';


$sql = "INSERT INTO ToDoList(userId, tdName)
VALUES('12','Study for Exams')";


 // Executing the query and checking if it has executed successfully
 if($conn->query($sql) === TRUE) 
 {
   echo "<br> Table 'ToDoList' Created Successfully";
 } 
 else 
 {
   echo "<br> Error Creating Table User: " . $conn->error;
 }

 $conn->close();
 

?>