<?php

/* 
    Author: Prizam
    Date: 25/07/23

    Starting a session and setting session varibles

    ---------------------This file is not used------------------------
    =====================but dont delete it==========================
*/

session_start();

?>

<?php
if(isset($_POST['submit_Signup']))
{
$_SESSION['un'] = $_POST['userName'];
$_SESSION['em'] = $_POST['email'];
$_SESSION['pw'] = $_POST['pass'];
include '../../Backend/Send_Email_Otp/SendOtp.php';
exit();
}


?>