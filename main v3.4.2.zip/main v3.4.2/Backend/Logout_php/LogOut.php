<?php

session_start();

// Prevent caching
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

if(isset($_SESSION['un']))
{
    unset($_SESSION['un']);

    if(isset($_SESSION['em']) && isset($_SESSION['pw']) && isset($_SESSION['userId']))
    {
        unset($_SESSION['em']);
        unset($_SESSION['pw']);
        unset($_SESSION['userId']);
    }
    header("Location: ../../Frontend/LogIn/LogIn.html");
}
else
{
    header("Location: ../../Frontend/LogIn/LogIn.html");
}
?>
