# Pomodoro Timer - Vanilla JavaScript  Free Code Camp ( FCC ) Zipline

A Pen created on CodePen.io. Original URL: [https://codepen.io/eddyerburgh/pen/yOjdqo](https://codepen.io/eddyerburgh/pen/yOjdqo).

Pomodoro timer made built with vanilla JavaScript. Built for a Free Code Camp zipline