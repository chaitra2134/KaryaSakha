Note - 
Inside the www folder (for WAMP) or ht docs folder (for XAMP)
first create a foler 'WT Group Project' and inside that folder unzip the main v3.4 file


Delete existing KaryaSakha database and the tables associated with it

Then Go to Backend\Connection_Database_Table
Run the Database.php file on your server and then
Run the UserTable.php file on your server



Now open Frontend/SignUp/SignUp.html and check out the various functionalities